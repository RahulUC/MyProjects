
using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ModaUltimo.Models
{
    public class Category
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }
        
        // public int ProductID { get; set; }
        //public Product Product { get; set; }

        public ICollection<Product> Products { get; set; }
        // ADD PROPERTIES HERE
    }
}
            