
using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ModaUltimo.Models
{
    public class Product
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Size { get; set; }
        public decimal Price { get; set; }
        
        public ICollection<Inventory> Inventories { get; set; }
        //public int InventoryID { get; set; }
        //public Inventory Inventory { get; set; }

        public int CategoryID { get; set; }
        public Category Category { get; set; }
        //
        // ADD PROPERTIES HERE
    }
}
            