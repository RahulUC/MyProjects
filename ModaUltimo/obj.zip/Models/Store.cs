
using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace ModaUltimo.Models
{
    public class Store
    {
        [Key]
        public int Id { get; set; }
        
        public string Street {get; set; }
        public string City {get; set; }
        public string State {get; set; }
        public int Zip {get; set; }
        // public bool? StoreOperation {get; set;}
        public DateTime Open_date {get; set; }
        public DateTime? Close_Date {get; set; }
        // ADD PROPERTIES HERE
        //public int InventoryID { get; set; }
        //public Inventory Inventory { get; set; }
       
         public ICollection<Inventory> Inventories { get; set; }

        

    }
}
            