using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ModaUltimo.Models;
using Microsoft.EntityFrameworkCore;

namespace ModaUltimo.Pages
{
    public class Inventory_ManagementModel : PageModel
    {

        private AppDbContext _context;
        
        public Inventory_ManagementModel(AppDbContext context) {
            _context = context;
        }
        public ICollection<Inventory> Inventories { get; set; }
        public ICollection<Store> Stores {get; set; }
        public ICollection<Product> Products {get; set; }
        
        public void OnGet()
        {
            Stores = _context.Store.
            Include(x => x.Inventories)
            //.OrderBy(x => x.Inventories.InventoryName)
            .ToList();
        }
    }
}